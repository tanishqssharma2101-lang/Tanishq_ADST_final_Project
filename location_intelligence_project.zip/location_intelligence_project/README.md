# Business Success Prediction & Location Intelligence System (Karnataka)

Scores candidate business locations (cafe / gym / bookstore / retail), explains the score, gives strategy tips,
and estimates revenue with an ML model. Backend = FastAPI, Frontend = Streamlit. Starter data is **synthetic**.

## Quick start
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python run_pipeline.py                                # clean data -> train model -> validate
uvicorn backend.main:app --reload                     # terminal 1  (API docs: http://127.0.0.1:8000/docs)
streamlit run frontend/app.py                         # terminal 2  (app: http://localhost:8501)
```
Streamlit also works alone (it falls back to the local engine if the API is not running).
Full step-by-step guide: see **ROADMAP.md**.
