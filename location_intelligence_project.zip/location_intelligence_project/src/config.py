"""Central settings: paths, factor lists, weight profiles, valid ranges.
Change things HERE, not scattered across files."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"

# The 7 factors used in the Location Success Score
FEATURES = [
    "population_density", "income_level", "foot_traffic", "competitor_density",
    "transport_access", "safety_score", "nearby_institutions",
]
EXTRA = ["rental_cost_per_sqft"]        # used by strategy rules + ML, not in the score weights
INVERT = {"competitor_density", "rental_cost_per_sqft"}   # lower raw value = better

# Weight profiles per business type. Each must sum to 1.0. Justify these in your report!
PROFILES = {
    "cafe":      {"population_density": .15, "income_level": .10, "foot_traffic": .20, "competitor_density": .20,
                  "transport_access": .15, "safety_score": .10, "nearby_institutions": .10},
    "gym":       {"population_density": .20, "income_level": .20, "foot_traffic": .10, "competitor_density": .15,
                  "transport_access": .15, "safety_score": .10, "nearby_institutions": .10},
    "bookstore": {"population_density": .10, "income_level": .10, "foot_traffic": .20, "competitor_density": .15,
                  "transport_access": .10, "safety_score": .10, "nearby_institutions": .25},
    "retail":    {"population_density": .20, "income_level": .15, "foot_traffic": .25, "competitor_density": .15,
                  "transport_access": .15, "safety_score": .05, "nearby_institutions": .05},
}

# Cleaning rules ---------------------------------------------------------------
KARNATAKA_BOUNDS = {"lat": (11.5, 18.5), "lon": (74.0, 78.6)}
VALID_RANGES = {                      # values outside these are treated as errors -> missing
    "population_density": (100, 60000), "income_level": (5000, 500000), "foot_traffic": (0, 3000),
    "competitor_density": (0, 100), "transport_access": (0, 50), "safety_score": (1, 10),
    "nearby_institutions": (0, 100), "rental_cost_per_sqft": (5, 1000),
    "seating_capacity": (1, 500), "monthly_revenue_inr": (0, 50_000_000),
}
INT_COLS = ["population_density", "foot_traffic", "competitor_density", "transport_access",
            "nearby_institutions", "city_tier", "seating_capacity"]
CITY_ALIASES = {
    "bangalore": "Bengaluru", "bengaluru": "Bengaluru", "bengalore": "Bengaluru",
    "mysore": "Mysuru", "mysuru": "Mysuru", "mangalore": "Mangaluru", "mangaluru": "Mangaluru",
    "hubli": "Hubballi-Dharwad", "hubballi": "Hubballi-Dharwad", "dharwad": "Hubballi-Dharwad",
    "hubballi-dharwad": "Hubballi-Dharwad", "hubli-dharwad": "Hubballi-Dharwad",
    "belgaum": "Belagavi", "belagavi": "Belagavi", "gulbarga": "Kalaburagi", "kalaburagi": "Kalaburagi",
    "davangere": "Davanagere", "davanagere": "Davanagere", "bellary": "Ballari", "ballari": "Ballari",
    "shimoga": "Shivamogga", "shivamogga": "Shivamogga", "tumkur": "Tumakuru", "tumakuru": "Tumakuru",
    "udupi": "Udupi", "hassan": "Hassan",
}
DEFAULT_SEATING = 40        # used when predicting revenue for a not-yet-built cafe
