"""STEP 2 - Feature engineering: min-max scale every factor to 0-1 (adds *_norm columns)."""
import pandas as pd
from .config import FEATURES, EXTRA


def _minmax(s: pd.Series) -> pd.Series:
    span = s.max() - s.min()
    return (s - s.min()) / span if span > 0 else pd.Series(0.5, index=s.index)


def add_normalized(df: pd.DataFrame, by_city: bool = False) -> pd.DataFrame:
    """by_city=False -> scale across the whole dataset (statewide comparison).
       by_city=True  -> scale inside each city (fair comparison within a city)."""
    out = df.copy()
    for c in FEATURES + EXTRA:
        out[c + "_norm"] = out.groupby("city")[c].transform(_minmax) if by_city else _minmax(out[c])
    return out
