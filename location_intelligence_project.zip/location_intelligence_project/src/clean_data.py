"""STEP 1 - Data cleaning.  Run:  python -m src.clean_data
Turns messy raw CSVs into analysis-ready CSVs and writes a cleaning report (great for your project report)."""
import json
import re
import numpy as np
import pandas as pd
from .config import (RAW, PROCESSED, FEATURES, EXTRA, VALID_RANGES, INT_COLS,
                     KARNATAKA_BOUNDS, CITY_ALIASES)

NUMERIC = FEATURES + EXTRA + ["lat", "lon", "city_tier", "seating_capacity", "monthly_revenue_inr"]


def to_number(s: pd.Series) -> pd.Series:
    """'₹65,000' -> 65000.0 ; 'abc' -> NaN"""
    txt = s.astype(str).str.replace(r"[^\d.\-]", "", regex=True).replace("", np.nan)
    return pd.to_numeric(txt, errors="coerce")


def clean(df: pd.DataFrame):
    rep = {"rows_in": int(len(df))}
    df = df.copy()

    # 1. tidy column names: ' Income Level ' -> income_level
    df.columns = [re.sub(r"\W+", "_", c.strip().lower()).strip("_") for c in df.columns]

    # 2. tidy text cells (strip spaces, empty -> NaN)
    for c in [c for c in ("location_id", "name", "district", "city", "cafe_id") if c in df]:
        df[c] = df[c].astype("string").str.strip().replace("", pd.NA).astype(object)

    # 3. standardise city names (Bangalore -> Bengaluru, Mysore -> Mysuru ...)
    if "city" in df:
        before = df["city"].copy()
        key = df["city"].astype(str).str.lower().str.strip()
        df["city"] = key.map(CITY_ALIASES).fillna(df["city"].astype(str).str.title())
        rep["city_names_standardised"] = int((before != df["city"]).sum())

    # 4. remove duplicates
    n = len(df)
    df = df.drop_duplicates()
    if "location_id" in df:
        df = df.drop_duplicates(subset="location_id")
    rep["duplicates_removed"] = int(n - len(df))

    # 5. force numeric columns to numbers
    for c in [c for c in NUMERIC if c in df]:
        df[c] = to_number(df[c])

    # 6. coordinates: fix swapped lat/lon, drop rows outside Karnataka
    if {"lat", "lon"} <= set(df.columns):
        swapped = (df.lat >= 70) & (df.lon <= 25)
        df.loc[swapped, ["lat", "lon"]] = df.loc[swapped, ["lon", "lat"]].values
        rep["coords_swapped_fixed"] = int(swapped.sum())
        (la0, la1), (lo0, lo1) = KARNATAKA_BOUNDS["lat"], KARNATAKA_BOUNDS["lon"]
        ok = df.lat.between(la0, la1) & df.lon.between(lo0, lo1)
        rep["rows_dropped_bad_coordinates"] = int((~ok).sum())
        df = df[ok]

    # 7. impossible values (negative competitors, safety=99 ...) -> missing
    invalid = {}
    for c, (lo, hi) in VALID_RANGES.items():
        if c in df:
            bad = df[c].notna() & ~df[c].between(lo, hi)
            if bad.any():
                invalid[c] = int(bad.sum())
                df.loc[bad, c] = np.nan
    rep["invalid_values_set_to_missing"] = invalid

    # 8. rows with no target can't be used for training
    if "monthly_revenue_inr" in df:
        n = len(df)
        df = df[df["monthly_revenue_inr"].notna()]
        rep["rows_dropped_missing_target"] = int(n - len(df))

    # 9. fill missing feature values: median of the same city, else global median
    imputed = {}
    for c in [c for c in FEATURES + EXTRA + ["seating_capacity"] if c in df]:
        miss = int(df[c].isna().sum())
        if miss:
            imputed[c] = miss
            if "city" in df:
                df[c] = df[c].fillna(df.groupby("city")[c].transform("median"))
            df[c] = df[c].fillna(df[c].median())
    rep["missing_values_imputed"] = imputed

    # 10. cap extreme outliers (3 x IQR rule) so one weird row can't squash the 0-1 scale
    capped = {}
    for c in [c for c in FEATURES + EXTRA if c in df]:
        q1, q3 = df[c].quantile([.25, .75])
        iqr = q3 - q1
        lo, hi = q1 - 3 * iqr, q3 + 3 * iqr
        n_out = int(((df[c] < lo) | (df[c] > hi)).sum())
        if n_out:
            capped[c] = n_out
            df[c] = df[c].clip(lo, hi)
    rep["outliers_capped"] = capped

    # 11. final types
    for c in [c for c in INT_COLS if c in df]:
        df[c] = df[c].round().astype(int)
    df = df.reset_index(drop=True)
    rep["rows_out"] = int(len(df))
    return df, rep


def run():
    PROCESSED.mkdir(parents=True, exist_ok=True)
    report = {}
    for src, dst in [("candidate_locations_raw.csv", "candidates_clean.csv"),
                     ("labeled_training_raw.csv", "labeled_clean.csv")]:
        out, rep = clean(pd.read_csv(RAW / src))
        out.to_csv(PROCESSED / dst, index=False)
        report[dst] = rep
        print(f"{src} -> {dst}: {rep['rows_in']} rows in, {rep['rows_out']} rows out")
    (PROCESSED / "cleaning_report.json").write_text(json.dumps(report, indent=2))
    print("Report saved to data/processed/cleaning_report.json")


if __name__ == "__main__":
    run()
