"""The 'brain' used by the API (and by the frontend as an offline fallback):
load cleaned data -> normalise -> score -> strategy tips -> ML revenue estimate -> rank."""
from functools import lru_cache
import joblib
import numpy as np
import pandas as pd
from .config import PROCESSED, MODELS, PROFILES, DEFAULT_SEATING
from .features import add_normalized
from .scoring import score_locations, normalize_weights
from .strategy import add_strategy


def load_candidates() -> pd.DataFrame:
    path = PROCESSED / "candidates_clean.csv"
    if not path.exists():
        raise FileNotFoundError("Run `python -m src.clean_data` first.")
    return pd.read_csv(path)


@lru_cache(maxsize=1)
def _model_bundle():
    p = MODELS / "model.joblib"
    return joblib.load(p) if p.exists() else None


def list_cities() -> list:
    return sorted(load_candidates()["city"].unique().tolist())


def _add_ml(df: pd.DataFrame, business: str) -> pd.DataFrame:
    bundle = _model_bundle()
    if bundle is None or business != "cafe":      # model was trained on cafe data only
        df["ml_predicted_revenue_inr"] = np.nan
        return df
    X = df.copy()
    X["seating_capacity"] = DEFAULT_SEATING
    df["ml_predicted_revenue_inr"] = bundle["model"].predict(X[bundle["features"]]).round(-2)
    return df


def rank(city: str | None = None, business: str = "cafe", scope: str = "city",
         weights: dict | None = None, top: int | None = None) -> pd.DataFrame:
    """scope='city'  -> factors scaled inside the chosen city (fair local comparison)
       scope='state' -> factors scaled across Karnataka, then filtered to the city"""
    df = load_candidates()
    if city:
        if city not in set(df["city"]):
            raise ValueError(f"Unknown city '{city}'. Options: {sorted(set(df['city']))}")
        if scope == "city":
            df = add_normalized(df[df["city"] == city].reset_index(drop=True))
        else:
            df = add_normalized(df)
            df = df[df["city"] == city].reset_index(drop=True)
    else:
        df = add_normalized(df)
    if weights is not None:
        weights = normalize_weights(weights)
    df = score_locations(df, business, weights)
    df = add_strategy(df)
    df = _add_ml(df, business)
    df = df.sort_values("location_success_score", ascending=False).reset_index(drop=True)
    df.insert(0, "rank", range(1, len(df) + 1))
    return df.head(top) if top else df
