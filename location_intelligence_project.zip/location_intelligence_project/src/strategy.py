"""STEP 4 - Rule-based strategy engine: factor pattern -> plain-English advice.
Works on the 0-1 *_norm columns (raw direction: competitor_density_norm high = MORE competition)."""
import pandas as pd

HIGH, LOW = 0.7, 0.3


def generate_strategy(row, high: float = HIGH, low: float = LOW, max_tips: int = 4) -> list:
    comp, foot = row["competitor_density_norm"], row["foot_traffic_norm"]
    inc, rent = row["income_level_norm"], row["rental_cost_per_sqft_norm"]
    tips = []
    if comp > high and foot > high:
        tips.append("High competition and high footfall: differentiate through a niche offering, service quality or experience - competing on volume alone will be hard.")
    elif comp < low and foot > high:
        tips.append("Low competition and high footfall: first-mover advantage - prioritise brand visibility and move fast before competitors arrive.")
    if inc > high and comp < low:
        tips.append("Higher income with light competition: a premium pricing and positioning strategy is viable here.")
    elif inc < low and foot > high:
        tips.append("Lower income but high footfall: favour value pricing, combo offers and a volume-driven model.")
    if row["transport_access_norm"] > high:
        tips.append("Strong transport access: invest in delivery/takeaway to capture demand beyond walking distance.")
    if row["nearby_institutions_norm"] > high:
        tips.append("Many nearby offices/schools: target weekday lunch hours, after-work promotions, student discounts and a weekend family focus.")
    if row["safety_score_norm"] < low:
        tips.append("Low safety score: invest in visible security, good lighting and safe-parking messaging in your marketing.")
    if row.get("location_success_score", 0) >= 60 and rent > high:
        tips.append("Good score but high rent: consider a smaller footprint, shared space or kiosk format to control fixed costs.")
    if len(tips) < 2:
        tips.append("Balanced profile with no extreme signals: win on execution - consistent quality, local marketing and loyalty offers.")
    return tips[:max_tips]


def add_strategy(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["strategy_tips"] = out.apply(generate_strategy, axis=1)
    return out
