"""Learning aid: deliberately breaks the dataset, then cleans it, so you SEE what clean_data.py does.
Run:  python -m src.demo_messy_data"""
import json
import numpy as np
import pandas as pd
from .config import RAW
from .clean_data import clean

rng = np.random.default_rng(1)
df = pd.read_csv(RAW / "candidate_locations_raw.csv")
df["income_level"] = df["income_level"].astype(object)

df.loc[rng.choice(len(df), 8, replace=False), "income_level"] = np.nan             # missing values
df.loc[rng.choice(len(df), 3, replace=False), "foot_traffic"] = np.nan
for i in rng.choice(len(df), 5, replace=False):                                     # numbers stored as text
    v = df.loc[i, "income_level"]
    df.loc[i, "income_level"] = "Rs " + format(int(float(v)), ",") if pd.notna(v) else v
df.loc[df.index[df.city == "Bengaluru"][:5], "city"] = "Bangalore"                  # inconsistent names
df.loc[df.index[df.city == "Mysuru"][:2], "city"] = " mysore "
df = pd.concat([df, df.iloc[:4]], ignore_index=True)                                # duplicate rows
df.loc[2, ["lat", "lon"]] = df.loc[2, ["lon", "lat"]].values                        # swapped coordinates
df.loc[7, "lat"] = 0.0                                                              # impossible coordinate
df.loc[9, "safety_score"] = 99                                                      # impossible value
df.loc[11, "competitor_density"] = -3
df.loc[13, "rental_cost_per_sqft"] = 9000                                           # absurd rent
df.columns = [c.title().replace("_", " ") for c in df.columns]                      # ugly headers

df.to_csv(RAW / "messy_demo.csv", index=False)
clean_df, rep = clean(df)
print(json.dumps(rep, indent=2))
print("\nCleaned shape:", clean_df.shape, "| remaining missing values:", int(clean_df.isna().sum().sum()))
