"""STEP 7 - Sanity checks (your 'validation' section).  Run: python -m src.validate
Does a known busy commercial area outscore a quiet/industrial one? If not, revisit weights or data."""
import numpy as np
from .config import PROFILES
from .engine import rank

# (city, area that SHOULD score higher, area that SHOULD score lower) - based on local knowledge
KNOWN_PAIRS = [
    ("Bengaluru", "MG Road", "Yelahanka"), ("Bengaluru", "Indiranagar", "Yelahanka"),
    ("Mangaluru", "Hampankatta", "Surathkal"), ("Belagavi", "Khade Bazar", "Udyambag"),
    ("Hubballi-Dharwad", "Vidyanagar (Hubballi)", "Gokul Road"), ("Kalaburagi", "Super Market", "Sedam Road"),
    ("Mysuru", "Devaraja Mohalla", "Bogadi"), ("Udupi", "City Bus Stand", "Kunjibettu"),
]


def area_score(df, area):
    m = df[df["name"] == area]["location_success_score"]
    return float(m.iloc[0]) if len(m) else np.nan


def run():
    ok = 0
    print("weights sum check:", {k: round(sum(v.values()), 6) for k, v in PROFILES.items()})
    for business in ("cafe", "retail"):
        print(f"\n[{business}]")
        for city, hi, lo in KNOWN_PAIRS:
            df = rank(city=city, business=business)
            a, b = area_score(df, hi), area_score(df, lo)
            passed = a > b
            ok += passed
            print(f"  {'PASS' if passed else 'FAIL'}  {city}: {hi} ({a}) vs {lo} ({b})")
    total = 2 * len(KNOWN_PAIRS)
    print(f"\n{ok}/{total} sanity checks passed")


if __name__ == "__main__":
    run()
