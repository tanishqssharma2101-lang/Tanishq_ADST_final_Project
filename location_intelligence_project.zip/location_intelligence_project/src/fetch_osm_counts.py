"""OPTIONAL - replace synthetic factors with REAL OpenStreetMap counts around each candidate site.
Run:  python -m src.fetch_osm_counts          (needs internet; Overpass is free but rate-limited - be polite)
Writes data/raw/candidate_locations_osm.csv. Rename it to candidate_locations_raw.csv (keep a backup of the old one)
and re-run `python run_pipeline.py`.   NOTE: written from the Overpass API docs - test it on 2-3 rows first."""
import time
import pandas as pd
import requests
from .config import RAW

URL = "https://overpass-api.de/api/interpreter"
# factor -> (Overpass tag filter, radius in metres)
QUERIES = {
    "competitor_density":  ('node["amenity"="cafe"]', 500),
    "nearby_institutions": ('nwr["amenity"~"school|college|university"]', 500),
    "transport_access":    ('node["highway"="bus_stop"]', 800),
    "foot_traffic":        ('nwr["shop"]', 500),         # shops as a proxy for footfall
}


def count_nearby(lat, lon, tag_filter, radius, retries=3):
    q = f"[out:json][timeout:25];{tag_filter}(around:{radius},{lat},{lon});out count;"
    for attempt in range(retries):
        try:
            r = requests.post(URL, data={"data": q}, timeout=40)
            if r.status_code == 429:                      # rate limited -> wait and retry
                time.sleep(10 * (attempt + 1)); continue
            r.raise_for_status()
            return int(r.json()["elements"][0]["tags"]["total"])
        except Exception as e:
            print("  retry:", e); time.sleep(5)
    return None


def run(limit=None):
    df = pd.read_csv(RAW / "candidate_locations_raw.csv")
    for i, row in df.head(limit).iterrows():
        for col, (flt, rad) in QUERIES.items():
            val = count_nearby(row.lat, row.lon, flt, rad)
            if val is not None:
                df.loc[i, col] = val
            time.sleep(1.5)                               # be gentle with the free server
        print(f"{i + 1}/{len(df)} {row['name']} done")
    df.to_csv(RAW / "candidate_locations_osm.csv", index=False)


if __name__ == "__main__":
    run()
