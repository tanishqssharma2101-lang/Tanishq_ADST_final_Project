"""STEP 5 - ML layer: predict monthly cafe revenue from location features.  Run: python -m src.train_model"""
import json
import joblib
import pandas as pd
from scipy.stats import spearmanr
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import mean_absolute_error, r2_score, root_mean_squared_error
from sklearn.model_selection import cross_val_score, train_test_split
from .config import PROCESSED, MODELS, FEATURES, EXTRA, DEFAULT_SEATING
from .features import add_normalized
from .scoring import score_locations

MODEL_FEATURES = FEATURES + EXTRA + ["city_tier", "seating_capacity"]
TARGET = "monthly_revenue_inr"


def candidate_models():
    models = {
        "RandomForest": RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=42, n_jobs=-1),
        "GradientBoosting": GradientBoostingRegressor(random_state=42),
    }
    try:                                            # optional: pip install xgboost
        from xgboost import XGBRegressor
        models["XGBoost"] = XGBRegressor(n_estimators=300, learning_rate=0.05, max_depth=4, random_state=42)
    except ImportError:
        pass
    return models


def train():
    MODELS.mkdir(exist_ok=True)
    df = pd.read_csv(PROCESSED / "labeled_clean.csv")
    X, y = df[MODEL_FEATURES], df[TARGET]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

    results, fitted = {}, {}
    for name, model in candidate_models().items():
        model.fit(X_tr, y_tr)
        pred = model.predict(X_te)
        results[name] = {
            "R2": round(r2_score(y_te, pred), 3),
            "MAE_inr": round(mean_absolute_error(y_te, pred)),
            "RMSE_inr": round(root_mean_squared_error(y_te, pred)),
            "CV_R2_mean": round(float(cross_val_score(model, X, y, cv=5, scoring="r2").mean()), 3),
        }
        fitted[name] = model
        print(name, results[name])

    best = max(results, key=lambda k: results[k]["R2"])
    model = fitted[best]
    imp = permutation_importance(model, X_te, y_te, n_repeats=10, random_state=42, n_jobs=-1)
    importance = dict(sorted(zip(MODEL_FEATURES, imp.importances_mean.round(4).tolist()), key=lambda kv: -kv[1]))

    # compare ML ranking with the weighted-score ranking on the real candidate list
    cand = pd.read_csv(PROCESSED / "candidates_clean.csv")
    scored = score_locations(add_normalized(cand), "cafe")
    scored["seating_capacity"] = DEFAULT_SEATING
    scored["ml_predicted_revenue_inr"] = model.predict(scored[MODEL_FEATURES]).round(-2)
    rho = float(spearmanr(scored["location_success_score"], scored["ml_predicted_revenue_inr"])[0])
    scored[["location_id", "name", "city", "location_success_score", "ml_predicted_revenue_inr"]].to_csv(
        MODELS / "ranking_comparison.csv", index=False)

    metrics = {"best_model": best, "models": results, "feature_importance": importance,
               "spearman_score_vs_ml": round(rho, 3), "n_train": len(X_tr), "n_test": len(X_te)}
    (MODELS / "metrics.json").write_text(json.dumps(metrics, indent=2))
    joblib.dump({"model": model, "features": MODEL_FEATURES, "name": best}, MODELS / "model.joblib")
    print(f"\nBest model: {best} | Spearman(score vs ML) = {rho:.3f}\nSaved models/model.joblib, metrics.json")


if __name__ == "__main__":
    train()
