"""STEP 3 - Location Success Score = sum(weight_i * factor_i) * 100   (competition & rent inverted)."""
import pandas as pd
from .config import FEATURES, INVERT, PROFILES


def normalize_weights(weights: dict) -> dict:
    """Keep only known factors, drop negatives, rescale so they sum to 1.0."""
    w = {f: max(float(weights.get(f, 0)), 0.0) for f in FEATURES}
    total = sum(w.values())
    if total == 0:
        raise ValueError("At least one weight must be > 0")
    return {f: v / total for f, v in w.items()}


def score_locations(df: pd.DataFrame, business: str = "cafe", weights: dict | None = None) -> pd.DataFrame:
    if weights is None and business not in PROFILES:
        raise ValueError(f"Unknown business type '{business}'. Choose from {list(PROFILES)}")
    w = normalize_weights(weights if weights is not None else PROFILES[business])
    out = df.copy()
    total = pd.Series(0.0, index=out.index)
    for f in FEATURES:
        x = out[f + "_norm"]
        if f in INVERT:
            x = 1 - x
        pts = w[f] * x * 100            # points this factor contributes (explains the score!)
        out["pts_" + f] = pts.round(1)
        total += pts
    out["location_success_score"] = total.round(1)
    return out
