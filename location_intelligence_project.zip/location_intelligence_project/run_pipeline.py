"""One command to rebuild everything:  python run_pipeline.py"""
from src import clean_data, train_model, validate

clean_data.run()
train_model.train()
validate.run()
print("\nDone. Start the backend:  uvicorn backend.main:app --reload\nThen the frontend:      streamlit run frontend/app.py")
