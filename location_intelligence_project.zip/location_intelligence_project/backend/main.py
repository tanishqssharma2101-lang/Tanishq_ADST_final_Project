"""BACKEND - FastAPI.  Run from the project root:  uvicorn backend.main:app --reload
Interactive docs (free!):  http://127.0.0.1:8000/docs"""
import json
import sys
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

sys.path.append(str(Path(__file__).resolve().parents[1]))
from src.config import PROFILES, FEATURES, MODELS          # noqa: E402
from src.engine import rank, list_cities                   # noqa: E402

app = FastAPI(title="Location Intelligence API", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def to_records(df):
    """DataFrame -> JSON-safe list (NaN becomes null, numpy types become plain numbers)."""
    return json.loads(df.to_json(orient="records"))


class CustomScoreRequest(BaseModel):
    weights: dict[str, float]
    city: Optional[str] = None
    business_type: str = "cafe"
    scope: str = "city"
    top: Optional[int] = None


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/meta")
def meta():
    """Everything the frontend needs to build its dropdowns."""
    return {"cities": list_cities(), "business_types": list(PROFILES), "factors": FEATURES, "profiles": PROFILES}


@app.get("/locations")
def locations(city: Optional[str] = None, business_type: str = "cafe",
              scope: str = Query("city", pattern="^(city|state)$"), top: Optional[int] = Query(None, ge=1, le=500)):
    try:
        df = rank(city=city, business=business_type, scope=scope, top=top)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"count": len(df), "results": to_records(df)}


@app.get("/locations/{location_id}")
def location_detail(location_id: str, business_type: str = "cafe", scope: str = "state"):
    df = rank(business=business_type)                      # statewide so any id is findable
    row = df[df["location_id"] == location_id]
    if row.empty:
        raise HTTPException(status_code=404, detail=f"No location {location_id}")
    return to_records(row)[0]


@app.post("/score")
def custom_score(req: CustomScoreRequest):
    """Re-score with the user's own weights (sliders in the frontend)."""
    try:
        df = rank(city=req.city, business=req.business_type, scope=req.scope, weights=req.weights, top=req.top)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"count": len(df), "results": to_records(df)}


@app.get("/model")
def model_info():
    p = MODELS / "metrics.json"
    if not p.exists():
        raise HTTPException(status_code=404, detail="Run `python -m src.train_model` first.")
    return json.loads(p.read_text())
