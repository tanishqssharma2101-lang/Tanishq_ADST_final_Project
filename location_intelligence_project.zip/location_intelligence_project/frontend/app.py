"""FRONTEND - Streamlit.  Run from the project root:  streamlit run frontend/app.py
Talks to the FastAPI backend; if the backend is not running it falls back to the local engine."""
import json
import os
import sys
from pathlib import Path

import folium
import pandas as pd
import requests
import streamlit as st
from streamlit_folium import st_folium

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))
from src.config import PROFILES, FEATURES, MODELS   # noqa: E402

st.set_page_config(page_title="Karnataka Location Intelligence", page_icon="📍", layout="wide")
LABELS = {f: f.replace("_", " ").title() for f in FEATURES}

# ---------------------------------------------------------------- data access (API first, local fallback)
api_url = st.sidebar.text_input("Backend API URL", os.getenv("API_URL", "http://127.0.0.1:8000"))


@st.cache_data(ttl=60, show_spinner=False)
def get_cities(api):
    try:
        r = requests.get(f"{api}/meta", timeout=5); r.raise_for_status()
        return r.json()["cities"], "API"
    except Exception:
        from src.engine import list_cities
        return list_cities(), "local"


@st.cache_data(ttl=60, show_spinner="Scoring locations...")
def get_ranked(api, city, business, scope, weights_json):
    weights = json.loads(weights_json) if weights_json else None
    try:
        if weights:
            r = requests.post(f"{api}/score", timeout=10,
                              json={"weights": weights, "city": city, "business_type": business, "scope": scope})
        else:
            params = {"business_type": business, "scope": scope, **({"city": city} if city else {})}
            r = requests.get(f"{api}/locations", params=params, timeout=10)
        r.raise_for_status()
        return pd.DataFrame(r.json()["results"]), "API"
    except Exception:
        from src.engine import rank
        return rank(city=city, business=business, scope=scope, weights=weights), "local"


# ---------------------------------------------------------------- sidebar controls
cities, source = get_cities(api_url)
st.sidebar.caption(f"Data source: {'FastAPI backend' if source == 'API' else 'local engine (backend not running)'}")
st.sidebar.header("Choose your scenario")
business = st.sidebar.selectbox("Business type", list(PROFILES), format_func=str.title)
city_choice = st.sidebar.selectbox("City", ["All Karnataka"] + cities)
city = None if city_choice == "All Karnataka" else city_choice
scope = "city"
if city:
    scope_label = st.sidebar.radio("Compare against", ["Other sites in this city", "All of Karnataka"])
    scope = "city" if scope_label.startswith("Other") else "state"

weights = None
with st.sidebar.expander("Custom weights (advanced)"):
    if st.checkbox("Override business-type weights"):
        weights = {f: st.slider(LABELS[f], 0.0, 1.0, float(PROFILES[business][f]), 0.05) for f in FEATURES}
        st.caption("Weights are rescaled to sum to 1 automatically.")

df, _ = get_ranked(api_url, city, business, scope, json.dumps(weights) if weights else "")
df["ml_predicted_revenue_inr"] = pd.to_numeric(df.get("ml_predicted_revenue_inr"), errors="coerce")
has_ml = df["ml_predicted_revenue_inr"].notna().any()

# ---------------------------------------------------------------- header + KPIs
st.title("📍 Business Success Prediction & Location Intelligence")
st.caption(f"Scenario: **{business.title()}** in **{city_choice}** - {len(df)} candidate sites. (Starter data is synthetic.)")
best = df.iloc[0]
k1, k2, k3, k4 = st.columns(4)
k1.metric("Best location", best["name"])
k2.metric("Top score", f"{best['location_success_score']:.1f} / 100")
k3.metric("Average score", f"{df['location_success_score'].mean():.1f}")
k4.metric("Sites analysed", len(df))

tab_rank, tab_map, tab_detail, tab_compare, tab_model = st.tabs(
    ["🏆 Ranking", "🗺️ Map", "🔍 Location detail", "⚖️ Compare", "🤖 ML model"])

# ---------------------------------------------------------------- ranking
with tab_rank:
    cols = ["rank", "name", "city", "location_success_score", "rental_cost_per_sqft"] + (["ml_predicted_revenue_inr"] if has_ml else [])
    st.dataframe(df[cols], width="stretch", hide_index=True, column_config={
        "location_success_score": st.column_config.ProgressColumn("Score", min_value=0, max_value=100, format="%.1f"),
        "rental_cost_per_sqft": st.column_config.NumberColumn("Rent (Rs/sqft)"),
        "ml_predicted_revenue_inr": st.column_config.NumberColumn("ML est. monthly revenue (Rs)", format="%d"),
    })
    st.download_button("Download ranking (CSV)", df.drop(columns=["strategy_tips"]).to_csv(index=False), "ranking.csv")

# ---------------------------------------------------------------- map
with tab_map:
    m = folium.Map(location=[df.lat.mean(), df.lon.mean()], zoom_start=12 if city else 7)
    for _, r in df.iterrows():
        color = "green" if r.location_success_score >= 65 else "orange" if r.location_success_score >= 45 else "red"
        folium.CircleMarker([r.lat, r.lon], radius=8, color=color, fill=True, fill_opacity=0.8,
                            tooltip=f"#{r['rank']} {r['name']} - {r.location_success_score}",
                            popup=f"<b>{r['name']}</b> ({r['city']})<br>Score: {r.location_success_score}").add_to(m)
    if city:
        m.fit_bounds([[df.lat.min(), df.lon.min()], [df.lat.max(), df.lon.max()]])
    st_folium(m, height=520, use_container_width=True, returned_objects=[])
    st.caption("Green >= 65, orange 45-65, red < 45")

# ---------------------------------------------------------------- detail
with tab_detail:
    name_to_id = dict(zip(df["name"], df["location_id"]))
    pick = st.selectbox("Select a location", df["name"], key="detail_pick")
    row = df[df["name"] == pick].iloc[0]
    c1, c2 = st.columns([1, 1])
    with c1:
        st.metric("Success score", f"{row.location_success_score:.1f} / 100", f"rank #{int(row['rank'])} of {len(df)}")
        if has_ml and pd.notna(row.ml_predicted_revenue_inr):
            st.metric("ML estimated monthly revenue", f"Rs {row.ml_predicted_revenue_inr:,.0f}")
        st.subheader("Why this score? (points per factor)")
        pts = pd.Series({LABELS[f]: row[f"pts_{f}"] for f in FEATURES})
        st.bar_chart(pts)
    with c2:
        st.subheader("Strategic recommendations")
        for tip in row["strategy_tips"]:
            st.markdown(f"- {tip}")
        st.subheader("Raw factors")
        raw = {LABELS[f]: row[f] for f in FEATURES}
        raw["Rent (Rs/sqft)"] = row["rental_cost_per_sqft"]
        st.dataframe(pd.DataFrame(raw, index=["value"]).T, width="stretch")

# ---------------------------------------------------------------- compare
with tab_compare:
    a, b = st.columns(2)
    n1 = a.selectbox("Location A", df["name"], index=0, key="cmp_a")
    n2 = b.selectbox("Location B", df["name"], index=min(1, len(df) - 1), key="cmp_b")
    ra, rb = df[df["name"] == n1].iloc[0], df[df["name"] == n2].iloc[0]
    st.bar_chart(pd.DataFrame({n1: {LABELS[f]: ra[f"pts_{f}"] for f in FEATURES},
                               n2: {LABELS[f]: rb[f"pts_{f}"] for f in FEATURES}}))
    ca, cb = st.columns(2)
    for col, r, n in ((ca, ra, n1), (cb, rb, n2)):
        col.metric(n, f"{r.location_success_score:.1f}")
        for tip in r["strategy_tips"]:
            col.markdown(f"- {tip}")

# ---------------------------------------------------------------- model
with tab_model:
    p = MODELS / "metrics.json"
    if p.exists():
        mt = json.loads(p.read_text())
        st.write(f"Best model: **{mt['best_model']}** (trained on {mt['n_train']} cafes, tested on {mt['n_test']})")
        st.dataframe(pd.DataFrame(mt["models"]).T, width="stretch")
        st.write(f"Rank agreement between weighted score and ML prediction (Spearman): **{mt['spearman_score_vs_ml']}**")
        st.subheader("What drives revenue? (permutation importance)")
        st.bar_chart(pd.Series(mt["feature_importance"]))
    else:
        st.info("Run `python -m src.train_model` to create model metrics.")
