# Full Roadmap: Business Success Prediction & Location Intelligence System (Karnataka)

A step-by-step build guide: **data cleaning -> features -> scoring -> strategy -> ML -> backend -> frontend -> validation -> deployment -> report**.
Every step names the file that implements it. The whole project in this folder is already runnable and tested, so you can
(a) run it first, (b) read each file, (c) change/extend it and explain it in your viva.

> Starter data is **synthetic** (generated with realistic ranges for 12 Karnataka cities). Say so in your report. Section 3 shows how to swap in real data.

---
## 1. Architecture

```
 RAW CSVs ──► clean_data.py ──► features.py ──► scoring.py ──► strategy.py ──┐
 (data/raw)   (data/processed)  (0-1 scaling)   (score 0-100)   (tips)       │
                    │                                                         ▼
                    └──► train_model.py ──► model.joblib ───────────────►  engine.py  (rank())
                                                                              │
                                                    BACKEND  backend/main.py (FastAPI, JSON over HTTP)
                                                                              │
                                                    FRONTEND frontend/app.py (Streamlit: table, map, charts)
```

**Folder structure**
```
location_intelligence_project/
├── data/raw/          candidate_locations_raw.csv, labeled_training_raw.csv, messy_demo.csv
├── data/processed/    candidates_clean.csv, labeled_clean.csv, cleaning_report.json
├── src/
│   ├── config.py        paths, weights, valid ranges, city-name aliases  (edit settings here)
│   ├── clean_data.py    STEP 2  cleaning pipeline
│   ├── demo_messy_data.py  breaks the data on purpose, then cleans it (learning aid)
│   ├── features.py      STEP 3  min-max normalisation
│   ├── scoring.py       STEP 4  weighted Location Success Score
│   ├── strategy.py      STEP 5  rule-based recommendations
│   ├── train_model.py   STEP 6  ML revenue model
│   ├── engine.py        glue: clean data -> score -> tips -> ML -> ranked table
│   ├── validate.py      STEP 9  sanity checks
│   └── fetch_osm_counts.py  OPTIONAL real OpenStreetMap data
├── backend/main.py    STEP 7  FastAPI REST API
├── frontend/app.py    STEP 8  Streamlit dashboard
├── models/            model.joblib, metrics.json, ranking_comparison.csv
├── run_pipeline.py    one command: clean -> train -> validate
└── requirements.txt
```

---
## 2. Step 0 - Setup (Week 1)
1. Install Python 3.10+ and VS Code; make a GitHub repo and commit early.
2. Create an isolated environment and install packages:
   ```bash
   python -m venv venv
   source venv/bin/activate            # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. Run everything once to confirm your machine works: `python run_pipeline.py`.
   Expected: cleaning summary, model metrics, and `16/16 sanity checks passed`.
4. Pick your scope in one sentence, e.g. *"Where should a new cafe open in Mysuru?"* (the guide recommends one business type and one city; the app still lets you explore all of Karnataka).

---
## 3. Step 1 - Data (Week 2)
**What you have:** `candidate_locations_raw.csv` (96 sites x 12 cities) and `labeled_training_raw.csv` (900 cafes with revenue).

| Column | Meaning | Direction |
|---|---|---|
| population_density | people per km2 | higher = better |
| income_level | household INR / month | higher = better |
| foot_traffic | OSM points of interest within 500 m | higher = better |
| competitor_density | cafes within 500 m | **lower = better** (inverted) |
| transport_access | bus/metro stops within 800 m | higher = better |
| safety_score | 1-10 | higher = better |
| nearby_institutions | offices + schools within 500 m | higher = better |
| rental_cost_per_sqft | INR / sqft / month | lower = better (used in strategy rules + ML) |

**Swapping in real data (do at least some of this for higher marks):**
- **Competitors, schools, bus stops, shops:** `python -m src.fetch_osm_counts` queries OpenStreetMap (Overpass) for every candidate coordinate. It needs internet and is rate-limited, so test on 2-3 rows first (`run(limit=3)`). I wrote it from the Overpass docs but could not run it from my sandbox, so treat it as untested.
- **Population & income:** district-level census tables from data.gov.in/sector/census.
- **Labeled revenue:** Kaggle "Restaurant Revenue Prediction" (137 rows, real) for your final ML metrics.
- **Rent:** no clean open dataset. Estimate from 99acres/MagicBricks listings and state it as a limitation.
- After replacing a column, keep the **same column names** and re-run `python run_pipeline.py`. Nothing else changes.

---
## 4. Step 2 - Data cleaning (Week 3) - `src/clean_data.py`
Real data is always messy. The cleaner does 11 things, in this order (the order matters):

| # | Action | Why |
|---|---|---|
| 1 | Standardise column names (`" Income Level "` -> `income_level`) | code stops breaking on typos/spaces |
| 2 | Strip whitespace, empty strings -> missing | hidden spaces break matching |
| 3 | Standardise city names (Bangalore/Bengalore -> Bengaluru, Mysore -> Mysuru ...) via `CITY_ALIASES` | otherwise one city becomes 3 groups |
| 4 | Drop duplicate rows / duplicate `location_id` | duplicates double-count a site |
| 5 | Force numeric columns to numbers (`"Rs 65,000"` -> 65000) | text numbers can't be scaled |
| 6 | Fix swapped lat/lon; drop points outside Karnataka's bounding box | a wrong coordinate puts a pin in the sea |
| 7 | Impossible values (safety = 99, negative competitors, rent = 9000) -> missing, using `VALID_RANGES` | catches typos |
| 8 | Drop training rows with no revenue | can't learn from a missing answer |
| 9 | Fill missing features with the **city median** (fallback: global median) | keeps rows without inventing extreme values |
| 10 | Cap outliers beyond 3 x IQR | one crazy value would squash everyone else on the 0-1 scale |
| 11 | Convert counts to integers | clean types |

Run it: `python -m src.clean_data` -> writes `data/processed/*.csv` and `cleaning_report.json`.
**See it work:** `python -m src.demo_messy_data` injects problems into a copy of your data and shows the report. Verified result: 100 messy rows in -> 95 out, 4 duplicates removed, 1 coordinate swap fixed, 3 impossible values blanked, 14 missing values filled, 0 missing remaining.
Put that report table in your project report as the "data cleaning" evidence.

---
## 5. Step 3 - Feature engineering - `src/features.py`
Min-max scaling puts every factor on 0-1: `(x - min) / (max - min)`. Without it, population (thousands) swamps safety (1-10).
`add_normalized()` adds `*_norm` columns. Two scopes (chosen in the sidebar):
- **Other sites in this city** - scaled inside the city (fair local comparison, the default).
- **All of Karnataka** - scaled across the state (Bengaluru dominates because it has the highest income, footfall and rent).

---
## 6. Step 4 - Location Success Score - `src/scoring.py`
`Score = 100 x Sum( weight_i x factor_i )`, where competition is inverted (`1 - norm`), so every weight is positive.

Worked example (cafe weights): population 0.8, income 0.6, footfall 0.9, competition 0.4 -> inverted 0.6, transport 0.7, safety 0.5, institutions 0.3:
`0.15x0.8 + 0.10x0.6 + 0.20x0.9 + 0.20x0.6 + 0.15x0.7 + 0.10x0.5 + 0.10x0.3 = 0.665 -> 66.5 / 100`

Weight profiles live in `config.py` (`PROFILES`): cafe, gym (income/population heavier), bookstore (offices/schools = 0.25), retail (footfall = 0.25).
**Justify every weight in the report**, e.g. "a gym depends on residents who can afford a membership, so income and population get 0.20 each."
Every row also gets `pts_<factor>` columns showing points contributed by each factor, which is what the dashboard's "Why this score?" chart draws.

---
## 7. Step 5 - Strategy engine - `src/strategy.py`
Simple thresholds on the normalised factors (high > 0.7, low < 0.3):

| Pattern | Advice |
|---|---|
| high competition + high footfall | differentiate (niche, service, experience) |
| low competition + high footfall | first-mover advantage, move fast |
| high income + low competition | premium pricing viable |
| low income + high footfall | value pricing, combos, volume model |
| strong transport | add delivery/takeaway |
| many offices/schools | weekday lunch, after-work, student offers |
| low safety | visible security, lighting, safe-parking messaging |
| score >= 60 but high rent | smaller footprint / kiosk |

Each site gets 2-4 tips (max 4; a fallback tip is added if fewer than 2 rules fire). Tip wording is cafe/food-oriented; adapt it per business type as an extension.

---
## 8. Step 6 - Machine learning - `src/train_model.py`
1. Features: the 8 location factors + `city_tier` + `seating_capacity`; target: `monthly_revenue_inr`.
2. 80/20 train-test split, plus 5-fold cross-validation.
3. Trains RandomForest and GradientBoosting (XGBoost too if installed), keeps the best by R2.
4. Reports **R2, MAE, RMSE** and **permutation importance** (which factors drive revenue; a simple alternative to SHAP).
5. Predicts revenue for your 96 candidate sites and measures how well that ranking agrees with the weighted score (Spearman).

Results on the starter data: GradientBoosting R2 = 0.75, MAE ~ Rs 23,900/month (RandomForest R2 = 0.66); Spearman(score vs ML) = 0.52.
Interpretation: the two methods agree moderately, which is expected, since the score uses your hand-picked weights and the ML model learns its own.
**Honest caveat:** revenue in the starter file was *generated from the features*, so these numbers are optimistic. Re-train on real data (Kaggle) for your final metrics. The model only applies to **cafes**, so the ML column is hidden for other business types.

---
## 9. Step 7 - Backend (Week 5) - `backend/main.py` (FastAPI)
The backend is a small web server: the frontend asks for data over HTTP, the server replies with JSON. Start it: `uvicorn backend.main:app --reload`, then open **http://127.0.0.1:8000/docs** for a free, interactive page where you can test every endpoint.

| Endpoint | What it does |
|---|---|
| `GET /health` | is the server alive? |
| `GET /meta` | cities, business types, factors, weight profiles (fills the dropdowns) |
| `GET /locations?city=Mysuru&business_type=cafe&scope=city&top=10` | ranked list with scores, tips, ML estimate |
| `GET /locations/{location_id}` | one location in detail |
| `POST /score` | re-score with custom weights: `{"weights": {"foot_traffic": 1, "income_level": 0.5}, "city": "Udupi"}` |
| `GET /model` | ML metrics |

Try it: `curl "http://127.0.0.1:8000/locations?city=Udupi&top=3&business_type=gym"`.
**How to extend:** add a new endpoint by writing a function with `@app.get("/path")`, calling `rank(...)` from `src/engine.py`. Business logic stays in `src/`, the API stays thin.

---
## 10. Step 8 - Frontend (Week 5) - `frontend/app.py` (Streamlit)
Run: `streamlit run frontend/app.py` -> http://localhost:8501. Streamlit turns Python into a web UI, so no HTML/JS is needed.

| Part | What the user sees |
|---|---|
| Sidebar | business type, city, comparison scope, optional custom-weight sliders, API URL |
| KPI row | best location, top score, average score, number of sites |
| Ranking tab | sortable table with score bars, rent, ML revenue, CSV download |
| Map tab | Folium map, pins coloured green / orange / red by score |
| Location detail tab | score, rank, "why this score" bar chart, strategy tips, raw factors |
| Compare tab | two sites side by side |
| ML model tab | model metrics, factor importance |

The frontend calls the **API first** (`requests.get(.../locations)`) and silently falls back to the local `src/engine.py` if the backend isn't running. The sidebar shows which one is used. Change colours/thresholds or add tabs directly in `app.py`.

---
## 11. Step 9 - Validation (Week 5) - `src/validate.py`
`python -m src.validate` checks that weights sum to 1 and that known busy places beat quiet ones in the same city (MG Road > Yelahanka, Hampankatta > Surathkal, Khade Bazar > Udyambag, Udupi City Bus Stand > Kunjibettu ...): **16/16 pass** for cafe and retail.
Add your own pairs from places you know personally; failures are valuable: they tell you which weight or data column to revisit. Interesting finding to discuss: in Bengaluru, Indiranagar scores lower than expected because heavy competition is penalised, which is why the strategy engine says "differentiate" rather than "avoid".

---
## 12. Step 10 - Deployment (optional, Week 6)
- **Simplest:** deploy only the Streamlit app on Streamlit Community Cloud: push the repo to GitHub, choose `frontend/app.py` as the main file. With no backend reachable, the app uses the local engine, so it still works. Commit `data/processed/` and `models/` (or run the pipeline in the build) so the files exist.
- **Two-service version:** host the backend on a service like Render or Railway with start command `uvicorn backend.main:app --host 0.0.0.0 --port $PORT`, then set the frontend's `API_URL` environment variable to that URL.
- For the viva, a screen recording of the demo is a good backup if Wi-Fi fails.

---
## 13. Week-by-week plan
| Week | Do | Files | Deliverable |
|---|---|---|---|
| 1 | Setup, repo, scope, run pipeline once | requirements.txt, run_pipeline.py | working environment |
| 2 | Understand data; collect real columns (OSM/census/Kaggle) | data/raw, fetch_osm_counts.py | raw data folder + source notes |
| 3 | Cleaning + normalisation; study the messy demo | clean_data.py, features.py | clean tables + cleaning report |
| 4 | Scoring weights + justification, strategy rules, ML + metrics | scoring.py, strategy.py, train_model.py | ranked list, tips, R2/MAE |
| 5 | API + dashboard + validation | backend/main.py, frontend/app.py, validate.py | runnable demo + validation write-up |
| 6 | Polish, report, slides, rehearse live demo | README.md | PDF report, slides, demo |

---
## 14. Report outline
1. Problem statement and objectives 2. Related approaches (site selection, weighted-overlay) 3. Data sources (state *synthetic starter + what you replaced*) 4. Cleaning (paste the table from `cleaning_report.json`) 5. Methodology: normalisation, formula, weights + reasons, strategy rules, ML 6. System design: architecture diagram, API table, screenshots 7. Results: top/bottom locations, 2 worked comparisons, ML metrics, validation 8. Limitations: synthetic/estimated data, no real rent or footfall, static snapshot, model trained on cafes only, weights are subjective 9. Future work: live OSM/Google Places data, per-business ML models, seasonal footfall, SHAP explanations.

---
## 15. Likely viva questions
- *Why normalise?* Different units/scales would let one factor dominate silently.
- *Why invert competition?* So every weight stays positive and "higher = better" everywhere.
- *How did you choose the weights?* Business reasoning per factor; sensitivity check using the custom sliders.
- *Weighted score vs ML?* Score needs no labelled outcomes and is explainable; ML learns patterns from data but needs labels. Compare them (Spearman).
- *Is R2 = 0.75 trustworthy?* Not on synthetic data - say so; evaluate on real Kaggle data.
- *How did you handle missing data?* City median, then global median; logged in the cleaning report.
- *Why FastAPI + Streamlit?* Clean separation: API serves data/logic, UI only displays; other clients (mobile, web) can reuse the API.

---
## 16. Troubleshooting
| Problem | Fix |
|---|---|
| `ModuleNotFoundError: src` | run commands from the **project root** and use `python -m src.xxx` |
| `Run python -m src.clean_data first` | run `python run_pipeline.py` |
| Streamlit says "local engine (backend not running)" | start `uvicorn backend.main:app --reload`, or ignore - it still works |
| Port already in use | `uvicorn ... --port 8001`, then set the API URL in the sidebar |
| Map blank | check internet (map tiles load online) |
| Scores look wrong after editing data | confirm column names are unchanged and re-run `python run_pipeline.py` |

## 17. Extension ideas (if you finish early)
Add a business type in `PROFILES`; per-business tip wording; a "what-if" slider for rent; SHAP plots (`pip install shap`); Google Places or OSM live pulls; export a PDF report from the app.
